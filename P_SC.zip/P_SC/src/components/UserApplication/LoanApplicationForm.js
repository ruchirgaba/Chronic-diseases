import React, { useState } from "react";
import "./LoanApplicationForm.css";
import HeaderLoggedIn from "../LoggedIn/HeaderLoggedIn";
import Footer from "../LoggedIn/Footer";

const LoanApplicationForm = () => {
  const [formData, setFormData] = useState({
    // Personal Details
    fullName: "",
    phoneNumber: "",
    maritalStatus: "",
    panNumber: "",
    passportNumber: "",
    gender: "",
    currentAddress: "",
    permanentAddress: "",
    dateOfBirth: "",

    // Employment Details
    occupationType: "",
    totalWorkExperience: "",
    monthlyCompanyIncome: "",
    unemploymentIncome: "",
    companyName: "",
    officeAddress: "",

    // Loan Details
    loanType: "",
    loanAmount: "",
    loanDuration: "",
    loanPurpose: "",

    // Existing Loan Details
    existingLoanFullName: "",
    existingLoanType: "",
    existingLoanContactNumber: "",
    existingLoanLender: "",
    existingLoanEmail: "",
    existingLoanOutstandingAmount: "",
    existingLoanAddress: "",
    existingLoanEMITenure: "",

    // References
    referenceFullName: "",
    referenceRelationship: "",
    referenceContactNumber: "",
    referenceAddress: "",
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const validateField = (name, value) => {
    let error = "";

    switch (name) {
      case "fullName":
        if (!value.trim()) error = "Full name is required";
        else if (value.trim().length < 2)
          error = "Name must be at least 2 characters";
        break;
      case "phoneNumber":
        if (!value.trim()) error = "Phone number is required";
        else if (!/^\d{10}$/.test(value.replace(/\D/g, "")))
          error = "Please enter a valid 10-digit phone number";
        break;
      case "panNumber":
        if (!value.trim()) error = "PAN number is required";
        else if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(value.toUpperCase()))
          error = "Please enter a valid PAN number";
        break;
      case "currentAddress":
        if (!value.trim()) error = "Current address is required";
        else if (value.trim().length < 10)
          error = "Please enter a complete address";
        break;
      case "permanentAddress":
        if (!value.trim()) error = "Permanent address is required";
        else if (value.trim().length < 10)
          error = "Please enter a complete address";
        break;
      case "dateOfBirth":
        if (!value.trim()) error = "Date of birth is required";
        break;
      case "companyName":
        if (!value.trim()) error = "Company name is required";
        break;
      case "loanAmount":
        if (!value.trim()) error = "Loan amount is required";
        else if (isNaN(value) || parseFloat(value) <= 0)
          error = "Please enter a valid amount";
        break;
      case "referenceFullName":
        if (!value.trim()) error = "Reference name is required";
        break;
      case "referenceContactNumber":
        if (!value.trim()) error = "Reference contact is required";
        else if (!/^\d{10}$/.test(value.replace(/\D/g, "")))
          error = "Please enter a valid 10-digit phone number";
        break;
      default:
        break;
    }

    return error;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Validate field if it has been touched
    if (touched[name]) {
      const error = validateField(name, value);
      setErrors((prev) => ({
        ...prev,
        [name]: error,
      }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched((prev) => ({
      ...prev,
      [name]: true,
    }));

    const error = validateField(name, value);
    setErrors((prev) => ({
      ...prev,
      [name]: error,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate all fields
    const newErrors = {};
    const requiredFields = [
      "fullName",
      "phoneNumber",
      "panNumber",
      "currentAddress",
      "permanentAddress",
      "dateOfBirth",
      "companyName",
      "loanAmount",
      "referenceFullName",
      "referenceContactNumber",
    ];

    requiredFields.forEach((field) => {
      const error = validateField(field, formData[field]);
      if (error) newErrors[field] = error;
    });

    setErrors(newErrors);
    setTouched(
      requiredFields.reduce((acc, field) => ({ ...acc, [field]: true }), {})
    );

    if (Object.keys(newErrors).length === 0) {
      console.log("Form submitted:", formData);
      alert("Application submitted successfully!");
    } else {
      alert("Please fix the errors in the form before submitting.");
    }
  };

  return (
    <div className="loan-application-container">
      <HeaderLoggedIn />

      <main className="application-main">
        <div className="container">
          <div className="application-header">
            <h1>Loan Application Form</h1>
            <p>Please fill out all the required information below</p>
          </div>

          <form onSubmit={handleSubmit} className="loan-form">
            {/* Loan Details Section */}
            <section className="form-section">
              <h2>Please fill the Loan Details:</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Loan Type:</label>
                  <select
                    name="loanType"
                    value={formData.loanType}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    className={`form-input ${
                      touched.loanType && errors.loanType ? "error" : ""
                    }`}
                    required
                  >
                    <option value="">Choose One</option>
                    <option value="gold">Gold Loan</option>
                    <option value="home">Home Loan</option>
                    <option value="education">Education Loan</option>
                    <option value="medical">Medical Loan</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Loan Amount Required:</label>
                  <input
                    type="text"
                    name="loanAmount"
                    value={formData.loanAmount}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.loanAmount && errors.loanAmount ? "error" : ""
                    }`}
                    required
                  />
                  {touched.loanAmount && errors.loanAmount && (
                    <small className="error-text">{errors.loanAmount}</small>
                  )}
                </div>
                <div className="form-group">
                  <label>Loan Duration:</label>
                  <input
                    type="text"
                    name="loanDuration"
                    value={formData.loanDuration}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Purpose of Loan:</label>
                  <input
                    type="text"
                    name="loanPurpose"
                    value={formData.loanPurpose}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
              </div>

              {/* Document Upload Sections */}
              <div className="document-sections">
                <div className="document-row">
                  <div className="document-group">
                    <h3>Gold Loan</h3>
                    <div className="document-item">
                      <span>KYC Document</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                    <div className="document-item">
                      <span>Driving Licence</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                  </div>

                  <div className="document-group">
                    <h3>Home Loan</h3>
                    <div className="document-item">
                      <span>Sale Agreement</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                    <div className="document-item">
                      <span>EC</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                  </div>

                  <div className="document-group">
                    <h3>Education Loan</h3>
                    <div className="document-item">
                      <span>Identity Proof</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                    <div className="document-item">
                      <span>Latest Passport Photo</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                  </div>

                  <div className="document-group">
                    <h3>Medical Loan</h3>
                    <div className="document-item">
                      <span>Medical Reg. Certificate</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                    <div className="document-item">
                      <span>Address Proof</span>
                      <div className="upload-box">
                        <div className="upload-icon">📁</div>
                        <span>Click to upload</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Document Upload Section */}
            <section className="form-section">
              <h2>Please attach all the required documents:</h2>
              <div className="document-upload-row">
                <div className="document-upload-group">
                  <h3>Photograph</h3>
                  <p>(Passport size photograph not exceeding 2mb)</p>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Identity Proof</h3>
                  <p>(Aadhaar Card, Pan Card, Voter ID, Driving License)</p>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Address Proof</h3>
                  <p>(Utility bills, Passport, Rental Agreement)</p>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Personal Details Section */}
            <section className="form-section">
              <h2>Please fill your personal details:</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Full Name:</label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.fullName && errors.fullName ? "error" : ""
                    }`}
                    required
                  />
                  {touched.fullName && errors.fullName && (
                    <small className="error-text">{errors.fullName}</small>
                  )}
                </div>
                <div className="form-group">
                  <label>Phone Number:</label>
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.phoneNumber && errors.phoneNumber ? "error" : ""
                    }`}
                    required
                  />
                  {touched.phoneNumber && errors.phoneNumber && (
                    <small className="error-text">{errors.phoneNumber}</small>
                  )}
                </div>
                <div className="form-group">
                  <label>Marital Status:</label>
                  <input
                    type="text"
                    name="maritalStatus"
                    value={formData.maritalStatus}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>PAN Number:</label>
                  <input
                    type="text"
                    name="panNumber"
                    value={formData.panNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className={`form-input ${
                      touched.panNumber && errors.panNumber ? "error" : ""
                    }`}
                    required
                  />
                  {touched.panNumber && errors.panNumber && (
                    <small className="error-text">{errors.panNumber}</small>
                  )}
                </div>
                <div className="form-group">
                  <label>Passport Number:</label>
                  <input
                    type="text"
                    name="passportNumber"
                    value={formData.passportNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Gender:</label>
                  <input
                    type="text"
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Current Address:</label>
                  <input
                    type="text"
                    name="currentAddress"
                    value={formData.currentAddress}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className={`form-input ${
                      touched.currentAddress && errors.currentAddress
                        ? "error"
                        : ""
                    }`}
                    required
                  />
                  {touched.currentAddress && errors.currentAddress && (
                    <small className="error-text">
                      {errors.currentAddress}
                    </small>
                  )}
                </div>
                <div className="form-group">
                  <label>Permanent Address:</label>
                  <input
                    type="text"
                    name="permanentAddress"
                    value={formData.permanentAddress}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className={`form-input ${
                      touched.permanentAddress && errors.permanentAddress
                        ? "error"
                        : ""
                    }`}
                    required
                  />
                  {touched.permanentAddress && errors.permanentAddress && (
                    <small className="error-text">
                      {errors.permanentAddress}
                    </small>
                  )}
                </div>
                <div className="form-group">
                  <label>Date of Birth:</label>
                  <input
                    type="text"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Typing !"
                    className={`form-input ${
                      touched.dateOfBirth && errors.dateOfBirth ? "error" : ""
                    }`}
                    required
                  />
                  {touched.dateOfBirth && errors.dateOfBirth && (
                    <small className="error-text">{errors.dateOfBirth}</small>
                  )}
                </div>
              </div>
            </section>

            {/* Employment Details Section */}
            <section className="form-section">
              <h2>Please fill the Employment/Occupation Details:</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Occupation Type:</label>
                  <input
                    type="text"
                    name="occupationType"
                    value={formData.occupationType}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Total work experience in years:</label>
                  <input
                    type="text"
                    name="totalWorkExperience"
                    value={formData.totalWorkExperience}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Unemployment/other income/Business income:</label>
                  <input
                    type="text"
                    name="unemploymentIncome"
                    value={formData.unemploymentIncome}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Monthly company Salary:</label>
                  <input
                    type="text"
                    name="monthlyCompanyIncome"
                    value={formData.monthlyCompanyIncome}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Company:</label>
                  <input
                    type="text"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.companyName && errors.companyName ? "error" : ""
                    }`}
                    required
                  />
                  {touched.companyName && errors.companyName && (
                    <small className="error-text">{errors.companyName}</small>
                  )}
                </div>
                <div className="form-group">
                  <label>Office Address:</label>
                  <input
                    type="text"
                    name="officeAddress"
                    value={formData.officeAddress}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
              </div>

              {/* Employment Document Uploads */}
              <div className="document-upload-row">
                <div className="document-upload-group">
                  <h3>6 months of salary slips</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Last 3 years of ITR</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Self employed proof.</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
              </div>

              <div className="document-upload-row">
                <div className="document-upload-group">
                  <h3>Employment proof</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Self employed proof</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
                <div className="document-upload-group">
                  <h3>Company address proof</h3>
                  <div className="upload-box large">
                    <div className="upload-icon">📁</div>
                    <span>Click to upload</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Existing Loan Details Section */}
            <section className="form-section">
              <h2>Please fill Existing Loan Details (if any):</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Full Name:</label>
                  <input
                    type="text"
                    name="existingLoanFullName"
                    value={formData.existingLoanFullName}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Loan Type:</label>
                  <input
                    type="text"
                    name="existingLoanType"
                    value={formData.existingLoanType}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Contact Number:</label>
                  <input
                    type="tel"
                    name="existingLoanContactNumber"
                    value={formData.existingLoanContactNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Lender:</label>
                  <input
                    type="text"
                    name="existingLoanLender"
                    value={formData.existingLoanLender}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Email:</label>
                  <input
                    type="email"
                    name="existingLoanEmail"
                    value={formData.existingLoanEmail}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Outstanding Amount:</label>
                  <input
                    type="text"
                    name="existingLoanOutstandingAmount"
                    value={formData.existingLoanOutstandingAmount}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>Address:</label>
                  <input
                    type="text"
                    name="existingLoanAddress"
                    value={formData.existingLoanAddress}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
                <div className="form-group">
                  <label>EMI Tenure Remaining:</label>
                  <input
                    type="text"
                    name="existingLoanEMITenure"
                    value={formData.existingLoanEMITenure}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                  />
                </div>
              </div>
            </section>

            {/* References Section */}
            <section className="form-section">
              <h2>References:</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Full Name:</label>
                  <input
                    type="text"
                    name="referenceFullName"
                    value={formData.referenceFullName}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.referenceFullName && errors.referenceFullName
                        ? "error"
                        : ""
                    }`}
                    required
                  />
                  {touched.referenceFullName && errors.referenceFullName && (
                    <small className="error-text">
                      {errors.referenceFullName}
                    </small>
                  )}
                </div>
                <div className="form-group">
                  <label>Relationship with Applicant:</label>
                  <input
                    type="text"
                    name="referenceRelationship"
                    value={formData.referenceRelationship}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Contact Number:</label>
                  <input
                    type="tel"
                    name="referenceContactNumber"
                    value={formData.referenceContactNumber}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className={`form-input ${
                      touched.referenceContactNumber &&
                      errors.referenceContactNumber
                        ? "error"
                        : ""
                    }`}
                    required
                  />
                  {touched.referenceContactNumber &&
                    errors.referenceContactNumber && (
                      <small className="error-text">
                        {errors.referenceContactNumber}
                      </small>
                    )}
                </div>
                <div className="form-group">
                  <label>Address:</label>
                  <input
                    type="text"
                    name="referenceAddress"
                    value={formData.referenceAddress}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Type here"
                    className="form-input"
                    required
                  />
                </div>
              </div>
            </section>

            {/* Submit Button */}
            <div className="form-submit-section">
              <button type="submit" className="submit-btn">
                Submit Application
              </button>
            </div>
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default LoanApplicationForm;
